% [pose_s] = PnL_cubic_stereo(xs1,xe1,xs2,xe2,xs3,xe3,V1',V2',V3',P1',P2',P3', alpha, beta, Rr1,Rr2,Rr3, tr1,tr2,tr3)
% compare with T_CW

function [pose] = NPnLupC(xs1, xe1, xs2, xe2, xs3, xe3, Vw1, Vw2, Vw3, Pw1, Pw2, Pw3, gamma, beta, Rr1, Rr2, Rr3, tr1, tr2, tr3)
% This function follows the framework of our NPnLupC algorithm:
% Nora Horanyi, Zoltan Kato, Multiview Absolute Pose Using 3D - 2D Perspective Line Correspondences and Vertical Direction, 
% In Proceedings of ICCV Workshop on Multiview Relationships in 3D Data, Venice, Italy, 2017, IEEE.

% Created: 2017-12-05,    using Matlab 9.2.0.556344 (R2017a)
% All rights reserved. 

% input: xs(:, i) = the start point of the ith image line [startpointx, startpointy, 1];
%       xe(:, i) = the end point of the ith image line   [endpointx,   endpointy, 1];
%       beta     = rotation angle around Y axis in radian
%       gamma    = rotation angle around Z axis in radian
%       Vw(:, i) = the direction of ith line in the world frame
%       Pw(:, i) = a point of ith line in the world frame

% output: rot_cw = the orientation of camera in rotation matrix parametrization
%                 (V_w = rot_cw * V_c)
%        pos_cw = the position of camera in global frame;
%                 (P_w = rot_cw * P_c + pos_cw;

% NOTE:
% 2D points should be normalized

ConditionErrThreshold = 1e-3;

for i=1:size(xs1,2)
    nc1(:,i) = cross(xs1(:,i),xe1(:,i));  nc1(:,i) = nc1(:,i)/norm(nc1(:,i));
end
for i=1:size(xs2,2)
    nc2(:,i) = cross(xs2(:,i),xe2(:,i));  nc2(:,i) = nc2(:,i)/norm(nc2(:,i));
end
for i=1:size(xs3,2)
    nc3(:,i) = cross(xs3(:,i),xe3(:,i));  nc3(:,i) = nc3(:,i)/norm(nc3(:,i));
end

%Construct Rv=Rr*Rz*Ry
Ry=[cos(beta) 0 sin(beta); 0 1 0; -sin(beta) 0 cos(beta)];
Rz=[cos(gamma), -sin(gamma), 0; sin(gamma), cos(gamma), 0; 0, 0, 1];

Rv1=Rr1*Rz*Ry;
Rv2=Rr2*Rz*Ry;
Rv3=Rr3*Rz*Ry;

for i=1:size(nc1,2)
    [ai1,bi1,ci1]=abc_solver(nc1(:,i), Rv1, Vw1(:,i));
    a(i) = 4*ai1^2;
    b(i) = 6*ai1*bi1;
    c(i) = 4*ai1*ci1 + 2*bi1^2;
    d(i) = 2*bi1*ci1;
end
for i=1:size(nc2,2)
    [ai2,bi2,ci2]=abc_solver(nc2(:,i), Rv2, Vw2(:,i));
    a(size(nc1,2)+i) = 4*ai2^2;
    b(size(nc1,2)+i) = 6*ai2*bi2;
    c(size(nc1,2)+i) = 4*ai2*ci2 + 2*bi2^2;
    d(size(nc1,2)+i) = 2*bi2*ci2;
end
for i=1:size(nc3,2)
    [ai3,bi3,ci3]=abc_solver(nc3(:,i), Rv3, Vw3(:,i));
    a(size(nc1,2)+size(nc3,2)+i) = 4*ai3^2;
    b(size(nc1,2)+size(nc3,2)+i) = 6*ai3*bi3;
    c(size(nc1,2)+size(nc3,2)+i) = 4*ai3*ci3 + 2*bi3^2;
    d(size(nc1,2)+size(nc3,2)+i) = 2*bi3*ci3;
end

a=sum(a);
b=sum(b);
c=sum(c);
d=sum(d);

q=roots([a b c d]);

q = q(imag(q)==0); % just real roots

optimumrot_cw = Inf(3,3);
optimumpos_cw = Inf(3,1);

minimalReprojectionError = 100;
for i=1:size(q,1)
    
    Rx = [q(i)^2+1, 0, 0; 0, -q(i)^2+1, -2*q(i); 0, 2*q(i), -q(i)^2+1]/(1 + q(i)^2);
    R1 = Rr1 * Rz * Ry * Rx;
    R2 = Rr2 * Rz * Ry * Rx;
    R3 = Rr3 * Rz * Ry * Rx;
    
    [Mat1]=matcalculation(size(Pw1,1), nc1, R1, Pw1, Rr1, tr1);
    [Mat2]=matcalculation(size(Pw2,1), nc2, R2, Pw2, Rr2, tr2);
    [Mat3]=matcalculation(size(Pw3,1), nc3, R3, Pw3, Rr3, tr3);
    Mat=[Mat1; Mat2; Mat3];
    [~, ~, VMat] = svd(Mat);
    vec = VMat(:,4);% the last column of Vmat;
    vec = vec/vec(4);
    
    %now, we get the rotation matrix rot_wc and translation pos_wc
    rot_wc = Rz*Ry*Rx;
    pos_wc = vec(1:3);
    pos_cw = rot_wc'*(-pos_wc);
    
    conditionErr = 0;
    for k=1:size(nc2,2)
        conditionErr = conditionErr + (nc2(:,k)' * rot_wc * Vw2(:,k))^2;
    end
    
    if conditionErr/size(Pw2,2) < ConditionErrThreshold
        %check whether the world scene is in front of the camera.
        numLineInFrontofCamera = 0;
        
        for j=1:size(Pw2,2)
            P_c = rot_wc*(Pw2(:,j) - pos_cw);
            if P_c(3) > 0
                numLineInFrontofCamera = numLineInFrontofCamera+1;
            end
        end
    else
        numLineInFrontofCamera = size(Pw2,2);
    end
    
    if numLineInFrontofCamera>0.5*size(Pw2,2)-1
        %most of the lines are in front of camera, then check the reprojection error.
        reprojectionError = 0;
        for l=1:size(Pw2,2)
            n_c = rot_wc * cross(Pw2(:,l) - pos_cw, Vw2(:,l));%line projection function
            h1 = n_c' * xs2(:,l);
            h2 = n_c' * xe2(:,l);
            lineLen = norm(xs2(:,l)-xe2(:,l))/3;
            reprojectionError = reprojectionError +  lineLen * (h1*h1 + h1*h2 + h2*h2) / (n_c(1)*n_c(1)+n_c(2)*n_c(2));
        end
        if reprojectionError < minimalReprojectionError
            optimumrot_cw = rot_wc';
            optimumpos_cw = pos_cw;
            minimalReprojectionError = reprojectionError;
        end
    end
end

rot_cw = optimumrot_cw;
pos_cw = optimumpos_cw;
pose = [rot_cw pos_cw; 0 0 0 1];
return

function [Mat]=matcalculation(n, nc, R, Pw, Rr, tr)
Mat = zeros(n, 4);
% tr= Rv * tr;
for i = 1:n
    nxi = nc(1,i);  nyi = nc(2,i);  nzi = nc(3,i);
    Pxi = Pw(1,i);        Pyi = Pw(2,i);        Pzi = Pw(3,i);
    
    % apply the constraint scalarproduct(Pi^c, ni^c) = 0
    Mat(2*i-1, 1) = nxi * Rr(1,1) + nyi * Rr(2,1) + nzi * Rr(3,1);
    Mat(2*i-1, 2) = nxi * Rr(1,2) + nyi * Rr(2,2) + nzi * Rr(3,2);
    Mat(2*i-1, 3) = nxi * Rr(1,3) + nyi * Rr(2,3) + nzi * Rr(3,3);
    Mat(2*i-1, 4) = nxi * (Pxi * R(1,1) + Pyi * R(1,2) + Pzi * R(1,3) )+ nyi * (Pxi * R(2,1) + Pyi * R(2,2) + Pzi * R(2,3) )+ nzi * (Pxi * R(3,1) + Pyi * R(3,2) + Pzi * R(3,3) ) + nxi*tr(1) + nyi*tr(2) + nzi * tr(3) ; %=(nc(:,i)'*tr)
end
return

function [a,b,c]=abc_solver(nc, Rv, Vw)
nxi = nc(1);        nyi = nc(2);        nzi = nc(3);
Vxi = Vw(1);        Vyi = Vw(2);        Vzi = Vw(3);

a = nxi * (Vxi * Rv(1,1) - Vyi * Rv(1,2) - Vzi * Rv(1,3)) + nyi * (Vxi * Rv(2,1) - Vyi * Rv(2,2) - Vzi * Rv(2,3)) + nzi * (Vxi * Rv(3,1) - Vyi * Rv(3,2) - Vzi * Rv(3,3));
b = 2 * (nxi * (Vyi * Rv(1,3)- Vzi * Rv(1,2)) + nyi * (Vyi * Rv(2,3)- Vzi * Rv(2,2)) + nzi * (Vyi * Rv(3,3)- Vzi * Rv(3,2)));
c = nxi * (Vxi * Rv(1,1) + Vyi * Rv(1,2) + Vzi * Rv(1,3)) + nyi * (Vxi * Rv(2,1) + Vyi * Rv(2,2) + Vzi * Rv(2,3)) + nzi * (Vxi * Rv(3,1) + Vyi * Rv(3,2) + Vzi * Rv(3,3));

return
