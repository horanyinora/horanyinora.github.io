% [pose_c] = gPnLup(camstruct)
% compare with GT=inv([camstruct.cambasic.GT_R camstruct.cambasic.GT_t; 0 0 0 1])

function [pose] = gPnLup(struct)
% This function follows the framework of our gPnLup algorithm:
% Nora Horanyi, Zoltan Kato, Generalized Pose Estimation from Line Correspondences with Known Vertical Direction, 
% In Proceedings of International Conference on 3D Vision, Qingdao, China, 2017, IEEE.

% Created: 2017-12-05,    using Matlab 9.2.0.556344 (R2017a)
% All rights reserved. 

% input: struct
% struct.camdata(i).lines_2D_start = normalized coordinates of the image line segment's startpoint on the unit sphere
% struct.camdata(i).lines_2D_end = normalized coordinates of the image line segment's endpoint on the unit sphere
% struct.camdata(i).lines_3D_start = start point of the 3D line segment in the world frame
% struct.camdata(i).lines_3D_end = end point of the 3D line segment in the world frame
% struct.camdata(i).relpose_R = 3*3 rotation matrix of the relative position
% struct.camdata(j).relpose_t = 3*1 translation vector of the relative position
% struct.cambasic.angles = known vertical direction angles

% output: pose = [rot_cw pos_cw; 0 0 0 1]; 4*4 matrix estimated absolute pose

%Calculate normal direction vectors
for i=1:size(struct.camdata  ,2)
    nc=[];
    xs=struct.camdata(i).lines_2D_start;
    xe=struct.camdata(i).lines_2D_end;
    for j=1:size(xs,1)
        nc(:,j) = cross(xs(j,:),xe(j,:));
        nc(:,j) = nc(:,j)/norm(nc(:,j));
    end
    n{i,:}=nc;
end

%Calculate direction vectors
for i=1:size(struct.camdata  ,2)
    
    Ai_temp=struct.camdata(i).lines_3D_start;
    Bi_temp=struct.camdata(i).lines_3D_end;
    for j=1:size(Ai_temp,1)
        dir = (Bi_temp(j,:) - Ai_temp(j,:))';
        V(j,:) = dir/norm(dir);
    end
    Vw{i,:}=V';
    P{i,:}=Ai_temp';
    Q{i,:}=Bi_temp';
end

%Calculate Rv matrix based on known vertical direction
beta=struct.cambasic.angles(2);
gamma=struct.cambasic.angles(1);

Ry=[cos(beta) 0 sin(beta); 0 1 0; -sin(beta) 0 cos(beta)];
Rz=[cos(gamma), -sin(gamma), 0; sin(gamma), cos(gamma), 0; 0, 0, 1];

for i=1:size(struct.camdata  ,2)    
    Rv{i,:}=struct.camdata(i).relpose_R*Rz*Ry;
end

%Solve equation in the single unknown q
for i=1:size(n,1)
    for j=1:size(n{i},2)
        [a_temp,b_temp,c_temp]=abc_solver(n{i,:}(:,j), Rv{i}, Vw{i,:}(:,j));
        a(i,j) = 4*a_temp^2;
        b(i,j) = 6*a_temp*b_temp;
        c(i,j) = 4*a_temp*c_temp + 2*b_temp^2;
        d(i,j) = 2*b_temp*c_temp;
    end    
end

a=sum(cat(2, a(:)));
b=sum(cat(2, b(:)));
c=sum(cat(2, c(:)));
d=sum(cat(2, d(:)));

q = roots([a b c d]);
q = q(imag(q)==0); 

optimumrot_cw = Inf(3,3);
optimumpos_cw = Inf(3,1);

ConditionErrThreshold = 1e-3*300;
minimalReprojectionError = 100;

% Calculate Rx with the real solutions, substitute Rx into (3), solve the linear equation in t(pos_wc)
for i=1:size(q,1)
    
    Rx = [q(i)^2+1, 0, 0; 0, -q(i)^2+1, -2*q(i); 0, 2*q(i), -q(i)^2+1]/(1 + q(i)^2);
    for j=1:size(struct.camdata  ,2)
        Rr=struct.camdata(j).relpose_R;
        tr=struct.camdata(j).relpose_t;
        
        R_temp=Rr * Rz * Ry * Rx;
        [Mat]=matcalculation(size(n{j},2), n{j}, R_temp, P{j}, Rr, tr);
        Mats{j,:}=Mat;
    end
    
    Mat=cat(1, Mats{:});
    [~, ~, VMat] = svd(Mat);
    vec = VMat(:,4);
    vec = vec/vec(4);
    
    %Calculate rotation matrix
    rot_wc = Rz*Ry*Rx;
    
    pos_wc = vec(1:3);
    pos_cw = rot_wc'*(-pos_wc);

    numLineInFrontofCamera = 0;
    numLineInFrontofCam = 0;
    P_total = 0;
    reprojection_error = 0;
    
    for z=1:size(struct.camdata  ,2)
        
        Rr=struct.camdata(z).relpose_R;
        conditionErr = 0;
        for k=1:size(n{z,:},2)
            conditionErr = conditionErr + (n{z,:}(:,k)' * Rr * rot_wc * Vw{z,:}(:,k))^2;
        end
        
        if conditionErr/size(P{z,:},2) < ConditionErrThreshold
            %check whether the world scene is in front of the camera.
            for j=1:size(P{z,:},2)
                P_c = Rr * rot_wc *(P{z,:}(:,j) - pos_cw);
                if P_c(3) > 0
                    numLineInFrontofCamera = numLineInFrontofCamera+1;
                end
            end
        else
            numLineInFrontofCamera = size(P{z,:},2);
        end
        numLineInFrontofCam=numLineInFrontofCam+numLineInFrontofCamera;
        P_total=P_total+size(P{z,:},2);
        
        compare(z)=numLineInFrontofCamera>0.5*size(P{z,:},2);
    end
    
    if sum(compare)==size(struct.camdata  ,2)
        %most of the lines are in front of camera, then check the reprojection error.
        
        for z=1:size(struct.camdata, 2)
            Rr=struct.camdata(z).relpose_R;
            tr=struct.camdata(z).relpose_t;
            xs=struct.camdata(z).lines_2D_start;
            xe=struct.camdata(z).lines_2D_end;
            
            reprojectionError = 0;
            sph_Error=0;
            for l=1:size(xs,1)

                n_c = cross(Rr *  rot_wc *(P{z,:}(:,l) - pos_cw)+tr, Vw{z,:}(:,l));% line projection function
                h1 = n_c' * xs(l,:)';
                h2 = n_c' * xe(l,:)';
                lineLen = norm(xs(l,:)-xe(l,:))/3;
                reprojectionError = reprojectionError +  lineLen * (h1*h1 + h1*h2 + h2*h2) / (n_c(1)*n_c(1)+n_c(2)*n_c(2));
 
                P_temp=Rr *  rot_wc *(P{z,:}(:,l) - pos_cw)+tr; P_len=norm(P_temp); P_temp=P_temp/P_len;
                Q_temp=Rr *  rot_wc *(Q{z,:}(:,l) - pos_cw)+tr; Q_len=norm(Q_temp); Q_temp=Q_temp/Q_len;
                
                n_c1 = cross(xs(l,:) ,xe(l,:));
                
                n_c2=cross(P_temp ,Q_temp)';
                n_C=n_c2/(norm(n_c2));
                
                sa=norm(cross(n_C,xs(l,:)));
                delta_a=atan(n_C*xs(l,:)'/sa);
                sb=norm(cross(n_C,xe(l,:)));
                delta_b=atan(n_C*xe(l,:)'/sb);
                
                sph_error=(delta_a^2+delta_b^2);
       
                sph_Error = sph_Error +  sph_error;
                
            end
            reprojection_error = reprojection_error+reprojectionError;
        end

        if reprojection_error < minimalReprojectionError
            optimumrot_cw = rot_wc';
            optimumpos_cw = pos_cw;
            minimalReprojectionError = reprojection_error;
        end
        
    end
end

rot_cw = optimumrot_cw;
pos_cw = optimumpos_cw;
pose = [rot_cw pos_cw; 0 0 0 1];
return

function [Mat]=matcalculation(n, nc, R, Pw, Rr, tr)
Mat = zeros(n, 4);
% tr= Rv * tr;
for i = 1:n
    nxi = nc(1,i);  nyi = nc(2,i);  nzi = nc(3,i);
    Pxi = Pw(1,i);        Pyi = Pw(2,i);        Pzi = Pw(3,i);
    
    % apply the constraint scalarproduct(Pi^c, ni^c) = 0
    Mat(2*i-1, 1) = nxi * Rr(1,1) + nyi * Rr(2,1) + nzi * Rr(3,1);
    Mat(2*i-1, 2) = nxi * Rr(1,2) + nyi * Rr(2,2) + nzi * Rr(3,2);
    Mat(2*i-1, 3) = nxi * Rr(1,3) + nyi * Rr(2,3) + nzi * Rr(3,3);
    Mat(2*i-1, 4) = nxi * (Pxi * R(1,1) + Pyi * R(1,2) + Pzi * R(1,3) )+ nyi * (Pxi * R(2,1) + Pyi * R(2,2) + Pzi * R(2,3) )+ nzi * (Pxi * R(3,1) + Pyi * R(3,2) + Pzi * R(3,3) ) + nxi*tr(1) + nyi*tr(2) + nzi * tr(3) ; %=(nc(:,i)'*tr)
end
return

function [a,b,c]=abc_solver(nc, Rv, Vw)
nxi = nc(1);        nyi = nc(2);        nzi = nc(3);
Vxi = Vw(1);        Vyi = Vw(2);        Vzi = Vw(3);

a = nxi * (Vxi * Rv(1,1) - Vyi * Rv(1,2) - Vzi * Rv(1,3)) + nyi * (Vxi * Rv(2,1) - Vyi * Rv(2,2) - Vzi * Rv(2,3)) + nzi * (Vxi * Rv(3,1) - Vyi * Rv(3,2) - Vzi * Rv(3,3));
b = 2 * (nxi * (Vyi * Rv(1,3)- Vzi * Rv(1,2)) + nyi * (Vyi * Rv(2,3)- Vzi * Rv(2,2)) + nzi * (Vyi * Rv(3,3)- Vzi * Rv(3,2)));
c = nxi * (Vxi * Rv(1,1) + Vyi * Rv(1,2) + Vzi * Rv(1,3)) + nyi * (Vxi * Rv(2,1) + Vyi * Rv(2,2) + Vzi * Rv(2,3)) + nzi * (Vxi * Rv(3,1) + Vyi * Rv(3,2) + Vzi * Rv(3,3));

return
