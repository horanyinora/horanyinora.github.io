% [pose_l] = PnL_vertical_stereo(xs1,xe1,xs2,xe2,xs3,xe3,V1',V2',V3',P1',P2',P3',alpha, beta, Rr1,Rr2,Rr3, tr1,tr2,tr3)
% compare with T_CW

function [pose] = NPnLupL(xs1, xe1, xs2, xe2, xs3, xe3, Vw1, Vw2, Vw3, Pw1, Pw2, Pw3, gamma, beta, Rr1, Rr2, Rr3, tr1, tr2, tr3)
% This function follows the framework of our NPnLupL algorithm:
% Nora Horanyi, Zoltan Kato, Multiview Absolute Pose Using 3D - 2D Perspective Line Correspondences and Vertical Direction, 
% In Proceedings of ICCV Workshop on Multiview Relationships in 3D Data, Venice, Italy, 2017, IEEE.

% Created: 2017-12-05,    using Matlab 9.2.0.556344 (R2017a)
% All rights reserved. 

% input:xs(:, i) = the start point of the ith image line [startpointx, startpointy, 1];
%       xe(:, i) = the end point of the ith image line   [endpointx,   endpointy, 1];
%       beta     = rotation angle around Y axis in radian
%       gamma    = rotation angle around Z axis in radian
%       Vw(:, i) = the direction of ith line in the world frame
%       Pw(:, i) = a point of ith line in the world frame
% output: rot_cw = the orientation of camera in rotation matrix parametrization
%                 (V_w = rot_cw * V_c)
%        pos_cw = the position of camera in global frame;
%                 (P_w = rot_cw * P_c + pos_cw;

% NOTE:
% 2D points should be normalized

for i=1:size(xs1,2)
    nc1(:,i) = cross(xs1(:,i),xe1(:,i));  nc1(:,i) = nc1(:,i)/norm(nc1(:,i));
end
for i=1:size(xs2,2)
    nc2(:,i) = cross(xs2(:,i),xe2(:,i));  nc2(:,i) = nc2(:,i)/norm(nc2(:,i));
end
for i=1:size(xs3,2)
    nc3(:,i) = cross(xs3(:,i),xe3(:,i));  nc3(:,i) = nc3(:,i)/norm(nc3(:,i));
end

%Construct Rv=Rr*Rz*Ry
Ry=[cos(beta) 0 sin(beta); 0 1 0; -sin(beta) 0 cos(beta)];
Rz=[cos(gamma), -sin(gamma), 0; sin(gamma), cos(gamma), 0; 0, 0, 1];

Rv1=Rr1*Rz*Ry;
Rv2=Rr2*Rz*Ry;
Rv3=Rr3*Rz*Ry;

[Mat1]=matcalculation(size(Pw1,2), nc1, Rv1, Vw1, Pw1, Rr1, tr1);
[Mat2]=matcalculation(size(Pw2,2), nc2, Rv2, Vw2, Pw2, Rr2, tr2);
[Mat3]=matcalculation(size(Pw3,2), nc3, Rv3, Vw3, Pw3, Rr3, tr3);
Mat=[Mat1; Mat2; Mat3];
[~, ~, VMat] = svd(Mat);

vec = VMat(:,6);
vec = vec/vec(6); %the condition that the last element of vec should be 1.
normalizeTheta = 1/sqrt(vec(1)*vec(1)+vec(2)*vec(2)); %the condition costheta^2+sintheta^2 = 1;
costheta = vec(1)*normalizeTheta;
sintheta = vec(2)*normalizeTheta;
Rx = [1 0 0; 0 costheta, -sintheta; 0, sintheta, costheta];

%now, we get the rotation matrix rot_wc and translation pos_wc
rot_wc = Rz* Ry * Rx;
pos_wc = vec(3:5);

rot_cw = rot_wc';
pos_cw = rot_cw*(-pos_wc);

rot_cw = rot_wc';
pose=[rot_cw pos_cw; 0 0 0 1];
return

function [Mat]=matcalculation(n, nc, Rv, Vw, Pw, Rr, tr)
Mat = zeros(2*n-1, 6);

for i = 1:n
    nxi = nc(1,i);  nyi = nc(2,i);  nzi = nc(3,i);
    
    %Vm = Rv * Vw(:,i);
    Vxi = Vw(1,i);        Vyi = Vw(2,i);        Vzi = Vw(3,i);
    
    %Pm = Rv * Pw(:,i);
    Pxi = Pw(1,i);        Pyi = Pw(2,i);        Pzi = Pw(3,i);
    
    % apply the constraint scalarproduct(Vi^c, ni^c) = 0
    %if i=1, then scalarproduct(Vi^c, ni^c) always be 0
    Mat(2*i, 1) = nxi * (Vyi * Rv(1,2)+ Vzi * Rv(1,3)) + nyi *(Vyi*Rv(2,2) + Vzi*Rv(2,3)) + nzi * (Vyi*Rv(3,2) + Vzi*Rv(3,3));
    Mat(2*i, 2) = nxi * (Vyi * Rv(1,3) - Vzi * Rv(1,2)) + nyi *(Vyi*Rv(2,3) - Vzi*Rv(2,2)) + nzi * (Vyi*Rv(3,3) - Vzi*Rv(3,2));
    Mat(2*i, 6) = nxi * (Vxi * Rv(1,1)) + nyi * (Vxi*Rv(2,1)) + nzi* (Vxi * Rv(3,1));
    
    % apply the constraint scalarproduct(Pi^c, ni^c) = 0
    Mat(2*i-1, 1) = nxi * (Pyi * Rv(1,2) + Pzi * Rv(1,3)) + nyi * (Pyi * Rv(2,2) + Pzi * Rv(2,3)) + nzi * (Pyi * Rv(3,2) + Pzi * Rv(3,3));
    Mat(2*i-1, 2) = nxi * (Pyi * Rv(1,3) - Pzi * Rv(1,2)) + nyi * (Pyi * Rv(2,3) - Pzi * Rv(2,2)) + nzi * (Pyi * Rv(3,3) - Pzi * Rv(3,2));
    Mat(2*i-1, 3) = nxi * Rr(1,1) + nyi * Rr(2,1) + nzi * Rr(3,1);
    Mat(2*i-1, 4) = nxi * Rr(1,2) + nyi * Rr(2,2) + nzi * Rr(3,2);
    Mat(2*i-1, 5) = nxi * Rr(1,3) + nyi * Rr(2,3) + nzi * Rr(3,3);
    Mat(2*i-1, 6) = nxi * Pxi * Rv(1,1) + nyi * Pxi * Rv(2,1) + nzi * Pxi * Rv(3,1) + nxi*tr(1) + nyi*tr(2) + nzi * tr(3) ; %=(nc(:,i)'*tr)
end
return
